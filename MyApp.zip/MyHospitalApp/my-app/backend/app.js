
// // const { Client } = require("pg");

// // const credentials = {
// //     user: "postgres",
// //     host: "localhost",
// //     database: "postgres",
// //     port: 5432,
// //     password:"postgres",
    
// //   };



// // // Connect with a client.

// //   const client = new Client(credentials);

// // client.connect();
// // console.log(client)

// // client.query(`select * from patient`,(res,err)=>{
// //     if(!err){
// //         console.log(res.rows);
// //     }
// //     else{
// //         console.log(err.message);

// //     }
// //     client.end();
// // });


// const { Pool, Client } = require("pg");

// const credentials = {
//   user: "postgres",
//   host: "localhost",
//   database: "postgres",
//   password: "postgres",
//   port: 5432,
// };

// // Connect with a connection pool.

// async function poolDemo() {
//   const pool = new Pool(credentials);
//   const now = await pool.query("SELECT NOW()");
//   await pool.end();

//   return now;
// }

// // Connect with a client.

// async function clientDemo() {
//   const client = new Client(credentials);
//   await client.connect();

//   const now = await client.query("SELECT NOW()");
 
//   await client.end();

//   return now;
// }

// // Use a self-calling function so we can use async / await.

// (async () => {
//   const poolResult = await poolDemo();
//   console.log("Time with pool: " + poolResult.rows[0]["now"]);

//   const clientResult = await clientDemo();
//   console.log("Time with client: " + clientResult.rows[0]["now"]);
// })();


const fs = require('fs');
const express = require('express');
const morgan= require('morgan');

const app = express();
//1) MIDDLEWARES

app.use(morgan('dev')); 
app.use(express.json());


// app.use((req,res,next)=> {
//     req.requestTime=new Date().toISOString();
//     next();
// })


const patients = JSON.parse(
  fs.readFileSync(`${__dirname}/dev-data/data/patients.json`)
);

//2) ROUTE HANDLERS
const getAllpatients=(req, res) => {
    
    console.log(req.requestTime);
    res.status(200).json({
      
      status: 'success',
      requestedAt:req.requestTime,
      
      results: patients.length,
      data: {
        
        patients, 
      },
    });
  }

const getPatientById= (req, res) => {
    console.log(req.params);

    const id=req.params.id*1; 
    const patient=patients.find(el => el.id === id);
    // 
    if(!patient){
        return res.status(404).json({
            status:'fail',
            message: 'Invalid Id'
        })
    }
    
    res.status(200).json({
      status: 'success',
        results: patients.length,
        data: {

            patient, 
        },
    });
  }


  
const createPatient=(req, res) => {
    //Middleware
  //   console.log(req.body);
  const newId= patients[patients.length-1].id + 1 ;
  const newPatient=Object.assign({ id: newId }, req.body);
  
  patients.push(newPatient);
  
  fs.writeFile(`${__dirname}/dev-data/data/patients.json`, JSON.stringify(patients), err=>{
      res.status(201).json({
          status: 'success',
          data:{
              patient:newPatient
          }
      });
  });
  }





//3)ROUTES
app
    .route('/api/v1/patients')
    .get(getAllpatients)
    .post(createPatient);


app
    .route('/api/v1/patient/:id')
    .get(getPatientById);





    //4) START SERVER
const port = 3000;
app.listen(port, () => {
  console.log(`App running on port ${port}...`);
});


